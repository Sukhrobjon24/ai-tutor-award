# AI Tutor

**AI Tutor** — bu ingliz tili, arab tili va matematika fanlarini AI yordamida o‘zlashtirish uchun mo‘ljallangan innovatsion ta’lim platformasi.

## Asosiy xususiyatlar:
- AI yordamida shaxsiylashtirilgan o‘quv yo‘nalishi
- Interaktiv mashqlar va suhbatlar
- Foydalanuvchi darajasiga mos o‘quv reja
- Global va mahalliy ta’lim ehtiyojlariga moslashtirilgan

## Platforma
- Web va mobil versiyada foydalanish imkoniyati
- Sun’iy intellekt asosidagi mashg‘ulotlar

## Kontakt
- Taqdim etuvchi: Suxrobjon Shukurov
- Loyihani qo‘llab-quvvatlovchi jamoa bilan